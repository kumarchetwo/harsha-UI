import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { FormsModule } from '@angular/forms';
import { trigger,state, style,transition,animation, animate } from '@angular/animations';
import { BrowserAnimationsModule } from  '@angular/platform-browser/animations';

var myanimations = [
    trigger("animation1",[
        state ("visible" ,style({transform: "scale(1)"})),
        state("invisible", style({transform: "scale(0)"})),
        transition("'=>'",animate("500ms"))
    ])
];

@Component({selector: "app",templateUrl:"AppComponentTemplate.html",animations:myanimations})
class AppComponent
{
    empid:number = 101;
    empname:string ="Scott";
    salary:number =4500;
    currentstate:string="Visible";

    ShowData(){
        this.currentstate= "visible";
    }

    HideData(){
        this.currentstate="invisible";
    }

}



@NgModule({declarations:[AppComponent],imports:[BrowserModule,FormsModule,BrowserAnimationsModule], bootstrap:[AppComponent]})
class AppModule{

}


platformBrowserDynamic().bootstrapModule(AppModule);






