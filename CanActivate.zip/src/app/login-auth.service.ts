import { Injectable ,Inject} from '@angular/core';
import { LoginStatusService } from './login-status.service';
import { Router ,RouterModule, ActivatedRouteSnapshot} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginAuthService {

  
  constructor(@Inject(LoginStatusService) private loginStstusService:LoginStatusService, @Inject(Router) private router:Router) { 

  }

  canActivate(route:ActivatedRouteSnapshot) : boolean
  {
    if(this.loginStstusService.isLoggedIn == false)
    {
      alert("You must to access electronics page");
      this.router.navigateByUrl("/");
    }
    return this.loginStstusService.isLoggedIn;
  }

}
