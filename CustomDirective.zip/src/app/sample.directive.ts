import { Directive, OnChanges, Inject, ElementRef, Input, HostListener } from '@angular/core';

@Directive({
  selector: '[appSample]'
})
export class SampleDirective  implements OnChanges{

  constructor(@Inject(ElementRef) private element: ElementRef) {
    this.element.nativeElement.style.border  ="1 px solid blue";
   }

   ngOnChanges(){

    this.element.nativeElement.setAttribute("src",this.secondimage);
   }

   @Input() firstimage : string;
   @Input() secondimage :string;
   @HostListener('mouseover')
   onMouseOver(){
     this.element.nativeElement.setAttribute("src",this.firstimage);
   }

   @HostListener('mouseout')
  onMouseOut(){
    this.element.nativeElement.setAttribute("src",this.secondimage);
  }


}
