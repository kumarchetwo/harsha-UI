export class Employee
{
    empid:number;
    empname:string;
    salary:number;
    constructor(a,b,c){
        this.empid=a;
        this.empname=b;
        this.salary=c;
    }
}