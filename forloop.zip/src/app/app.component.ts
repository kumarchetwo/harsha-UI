import { Component } from '@angular/core';
import { Employee } from './employee';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'forloop';
  cities: string[]=["New Delhi","Hyderabad","Banagalore","Chennai"];
  country: string =null;
employees: Employee[] =[
  new Employee(1,"Scott",4000),
  new Employee(2,"tiger",5000),
  new Employee(3,"amar",7000),
  new Employee(4,"chintha",9000),
  new Employee(5,"sun",2000)
];

newemployee:Employee = new Employee(null,null,null);
onInsertClick(){
  this.employees.push(new Employee(this.newemployee.empid,this.newemployee.empname,this.newemployee.salary));
  this.newemployee.empid=null;
  this.newemployee.empname=null;
  this.newemployee.salary=null;
}
onDeleteClick(n){
  if(confirm("Are you sure to delete this employee?")){
    this.employees.splice(n,1);
  }
}

}
