import { Component, OnInit,OnDestroy } from '@angular/core';
import { Observable } from "rxjs/Observable";
import "rxjs/rx";
import { Subscription } from "rxjs/Subscription";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit , OnDestroy {

  subscription:Subscription;
  ngOnInit(){
  //var mynumbers=Observable.interval(1000);
  //var mynumbers=Observable.range(11,20);
  var myarray= [10,20,30,40,50];
  var mynumbers=Observable.from(myarray);
  var txtClick =Observable.fromEvent(document.getElementById("txt1"),"keyup");
 this.subscription =txtClick.subscribe(
  //this.subscription= mynumbers.subscribe(
    (n) =>{
      console.log(n);
    },
    (error) =>{
      console.log(error);
      
    },
    ()=>{
      console.log("Complted");
    });
  }
  

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }
}
