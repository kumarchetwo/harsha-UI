import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-online-shopping',
  templateUrl: './online-shopping.component.html',
  styleUrls: ['./online-shopping.component.css']
})
export class OnlineShoppingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
