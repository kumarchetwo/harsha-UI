import { Injectable } from '@angular/core';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  products: Product[];
  constructor() { 
    this.products=[
      new Product(101,"Samsung 08",2400,"Samsung"),
      new Product(102,"Samsung 10 Electiric",2500,"Apple"),
      new Product(103,"GEHAIER",2400,"Google"),
      new Product(104,"CAFE",2400,"Google"),
    ];
  }

  getProductByBrand(brandName: string):Product[]
  {
  
     var selectedProducts : Product[]=[];
     for(var i=0; i<this.products.length;i++)
     {
       if(this.products[i].brand== brandName)
       {
         selectedProducts.push(this.products[i]);
       }
     }
     return selectedProducts;

  }
}
