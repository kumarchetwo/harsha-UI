import { Component, OnInit, Inject } from '@angular/core';
import { Product } from  '../product';
import { ProductsService } from '../products.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
 brand: string="";
 matchingProducts:Product[]=[];

  constructor(@Inject(ProductsService) private prodsService:ProductsService , @Inject(ActivatedRoute) private route:ActivatedRoute)   { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      var selectedBrand =params["brandname"];
      this.brand =selectedBrand;
      this.matchingProducts= this.prodsService.getProductByBrand(selectedBrand);
    });
  }

}
