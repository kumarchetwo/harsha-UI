import { Component , Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'AjaxSimpleJava';
  message: string=null;
  constructor(@Inject(HttpClient) private http:HttpClient){

  }

  onGetDataClick(){
    this.http.get("/SampleServlet",{responseType: "text"}) .subscribe(this.onAjaxSuccess, this.onAjaxError);
  }
  onAjaxSuccess=(response) => {
    this.message=response;
  }
  onAjaxError=(error)=> {
    this.message= error;
    alert(error);
  }
}
