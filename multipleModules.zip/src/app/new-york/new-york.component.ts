import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-york',
  templateUrl: './new-york.component.html',
  styleUrls: ['./new-york.component.css']
})
export class NewYorkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
