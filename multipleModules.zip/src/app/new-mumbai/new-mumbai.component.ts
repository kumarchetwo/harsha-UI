import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-mumbai',
  templateUrl: './new-mumbai.component.html',
  styleUrls: ['./new-mumbai.component.css']
})
export class NewMumbaiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
