import { Component, OnInit ,OnDestroy } from '@angular/core';
import { Observable } from "rxjs/Observable";
import { Observer } from "rxjs/Observer";
import "rxjs/rx";
import { Subscription } from "rxjs/Subscription";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit ,OnDestroy {

  subscription:Subscription;

  ngOnInit() {
    var myObservable = Observable.create((observer: Observer<string>) =>
    {
      setTimeout(() => { observer.next("first data package");},2000);
      setTimeout(() => { observer.next("second data package");},5000);
      setTimeout(() => { observer.next("third data package");},8000);
      setTimeout(() => { observer.complete();},10000);
      setTimeout(() => { observer.next("fourth data package");},12000);
    });
this.subscription = myObservable.subscribe(
  (n) => {
    console.log(n);
  },
  (error) => {
    console.log(error);
  },
  () =>{
    console.log("Completed");
  });
  }


  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

}


