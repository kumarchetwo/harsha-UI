import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'application';
  username : string = "";
  password : string = "";
  confirmpassword : string = "";
  acceptlicenseagreement:boolean = false;
  gender: string ="";
  country: string ="";
  msg:string ="";
  marks:number=78;
  mycolor:string ="";
  b:boolean;
  myclass: string ="";

  constructor(){
    if(this.marks>=35){
      this.mycolor="blue";
      this.b=true;
      this.myclass="class1";
    }
    else{
      this.mycolor="red";
      this.b=false;
      this.myclass="class2";
    }
  }
  
  RegisterClick(){
    this.msg="Username:"+this.username+"<br>PAssowrd:"+this.password+"<br>Confirm Password:"+this.confirmpassword+"<br> AcceptLicence:"+this.acceptlicenseagreement+"<br>Gender:"+this.gender+"<br>Country:"+this.country+"<br>marks:"+this.marks;
  }

  CheckLogin(txt1){
    if(this.username == "admin" && this.password == "manager"){
      this.msg="Successful Login";
    }else{
      this.msg="Invalid Login";
      txt1.focus();

    }
  }

}
