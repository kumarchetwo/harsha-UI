import { Component, ViewChild } from '@angular/core';
import { EmployeeComponent } from '../employee/employee.component';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent {

  companyName : string ="Tech Mahindra India Pvt Ltd";

  @ViewChild(EmployeeComponent) emp : EmployeeComponent;
  onClickMeClicked(){
    console.log(this.emp);
    this.emp.empname="Kyatham";
  }
  constructor() { }

  ngOnInit(): void {
  }

}
