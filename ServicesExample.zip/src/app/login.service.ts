import { Injectable } from '@angular/core';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  users: User [] =[
    new User("Scott","Scott123"),
    new User("smith","Smith123"),
    new User("allen","allen123")

  ]
  constructor() { }
  checkUsernameAndPassword(username:string,password:string){
    var count=0;
    for(var i=0;i<this.users.length; i++){
      if(this.users[i].username==username && this.users[i].password ==password){
        count++;
      }
    }
    if(count ==1 ){
      return true;
    }else{
      return false;
    }
  }
}
