import { Injectable } from '@angular/core';
import { CanDeactivate} from '@angular/router';
import { CanComponenetDeactivate } from './can-componenet-deactivate';

@Injectable({
  providedIn: 'root'
})
export class CanDeactivateGuardService  implements CanDeactivate<CanComponenetDeactivate>{

  canDeactivate(componenet: CanComponenetDeactivate){
    if(componenet.canNavigate == true){
      return true;
    }else{
      if(confirm("Do you want to disacard changes")){
        return true;
      } 
      else{
        return false;
      }
    }
  }

  constructor() { }
}
