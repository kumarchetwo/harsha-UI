import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  firstName:string=null;
  lastName:string=null;
  canNavigate:boolean=true;
  constructor() { }

  onFirstNameChange(){
    this.canNavigate=false;
  }

  onLastNameChange(){
    this.canNavigate=false;

  }
  onSave(){
    this.canNavigate=true;
    alert("Saved");
  }

  ngOnInit(): void {
  }

}
