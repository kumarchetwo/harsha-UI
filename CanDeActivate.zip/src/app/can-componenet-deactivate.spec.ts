import { CanComponenetDeactivate } from './can-componenet-deactivate';

describe('CanComponenetDeactivate', () => {
  it('should create an instance', () => {
    expect(new CanComponenetDeactivate()).toBeTruthy();
  });
});
