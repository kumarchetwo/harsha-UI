export class CanComponenetDeactivate {
    canNavigate:boolean;
    
}
