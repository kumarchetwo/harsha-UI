import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'appl';
  firstname : string = "Balkumar";
  lastname: string = "Kyatham";
  age:number = 40;
  recivenewsletters :boolean =true;
  gender :string = "Male";
  country : string = "India";
  address : string = "http://www.facebook.com";

  ChangeData(){
    this.firstname ="Bala";
    this.lastname ="kya";
    this.age= 45;
    this.recivenewsletters = false;
    this.gender ="Female";
    this.country="USA";
  }

}
