import { Component, OnInit ,Inject } from '@angular/core';
import { PopulationService } from '../population.service';

@Component({
  selector: 'app-usa',
  templateUrl: './usa.component.html',
  styleUrls: ['./usa.component.css']
})
export class UsaComponent implements OnInit {
indiapopulation :number =1.32;

  constructor(@Inject(PopulationService) private ps : PopulationService) 
   { 
      this.indiapopulation= this.ps.IndiaPopulation;
   }

  ngOnInit(): void {
  }

}
