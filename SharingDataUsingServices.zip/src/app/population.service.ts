import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PopulationService {
 IndiaPopulation : number;
  constructor() { }
}
