export interface Post {
    title: string;
    category: string;
    date_posted: Date;
    position: number;
    body: string;
  }