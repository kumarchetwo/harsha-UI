import { Component, ViewChild, QueryList, ViewChildren } from '@angular/core';
import {  EmployeeComponent } from '../employee/employee.component';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent {

  companyName:string ="Tech Mahindra";
  @ViewChildren( EmployeeComponent) emp : QueryList<EmployeeComponent>;
  
  onClickMeClicked()
  {
    console.log(this.emp);
    var a=this.emp.toArray();
    for(var i=0;i<a.length;i++){
      a[i].empname="Kyatham";
    }
  }
  constructor() { }

  ngOnInit(): void {
  }

}
