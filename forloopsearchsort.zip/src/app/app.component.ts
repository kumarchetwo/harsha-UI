import { Component } from '@angular/core';
import { Employee } from "./employee";
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'forloopsearchsort';
  originalemployees : Employee[]=[
    new Employee(1,"Bala",1000),
    new Employee(2,"Kumar",2000),
    new Employee(3,"Vasrhini",3000),
    new Employee(4,"Siddi",4000),
    new Employee(5,"Scott",5000)

  ];

  employees:Employee[]=[];
  constructor(){
    this.employees=this.originalemployees;
  }
  str:string="";
  sortcolumn="empid";
  order=1;

onSearchClick(){
  this.employees=this.originalemployees.filter((emp) => { return 
  emp.empname.toLocaleLowerCase().indexOf(this.str.toLocaleLowerCase()) >=0 });
}
onSortClick(){
  this.employees=this.originalemployees.sort((emp1,emp2) => {
    var n=0;
    if(this.sortcolumn=="empid"){
      return (emp1[this.sortcolumn] -emp2[this.sortcolumn]) * this.order;
    }
    else if(this.sortcolumn== "empname"){
return (emp1[this.sortcolumn].charCodeAt(0)-emp2[this.sortcolumn].charCodeAt(0)) * this.order;
    }
    else{
      return (emp1[this.sortcolumn] -emp2[this.sortcolumn]) * this.order;
    }
  })
}

}
