import { Component, OnInit, Inject } from '@angular/core';
import { PopulationService } from '../population.service';
import { Subscription } from 'rxjs';
import 'rxjs/add/operator/filter';

@Component({
  selector: 'app-usa',
  templateUrl: './usa.component.html',
  styleUrls: ['./usa.component.css']
})
export class UsaComponent implements OnInit {
indiapopulation:number =1.32;
subscription:Subscription;
  constructor(@Inject(PopulationService) private ps:PopulationService) {

   }

   // this custom observable using with service
  // ngOnInit() {
  //   this.subscription = this.ps.myObservable.subscribe(
  //     (n)=>{
  //       this.indiapopulation=n;
  //     },
  //     (error) => {
  //       console.log(error);
  //     },
  //     () =>{
  //       console.log("Completed");
  //     });
  
  // }

  // map 
  // ngOnInit() {
  //   this.subscription = this.ps.myObservable.map(((item)=>{
  //       return item * 1000;
  //     })
  //     .subscribe(
  //        (n) => {
  //     this.indiapopulation = n;
  //   },

  //     (error) => {
  //       console.log(error);
  //     },
  //     () =>{
  //       console.log("Completed");
  //     }));
  
  // }

  ngOnInit(){
    this.subscription =this.ps.myObservable.filter((item)=>
    {
      if(parseInt(String(item)) %2== 0){
        return true;
      }
      else{
        return false;
      }
    })

    .subscribe(
      (n) => {
        this.indiapopulation = n;
      },
      (error) =>{
        console.log(error);
      },
      () =>{
        console.log("Completed");
      });
    
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

}
